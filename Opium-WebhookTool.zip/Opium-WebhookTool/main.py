# Made by Proxy / Opiumtools for more join https://discord.gg/opiumtools
import os
import requests
import colorama
from dhooks import Webhook
import time
import ctypes

os.system('mode 62, 14')
ctypes.windll.kernel32.SetConsoleTitleW(f"OPIUM WEBHOOK TOOL")
def main():
    print(f'''{colorama.Fore.RED}
                 ____  ___  ______  ____  ___
                / __ \/ _ \/  _/ / / /  |/  /
               / /_/ / ___// // /_/ / /|_/ / 
               \____/_/  /___/\____/_/  /_/   ''')

    print(f"""{colorama.Fore.RED}
                   01 ~ Webhook Sender
                   02 ~ Webhook Spammer
                   03 ~ Webhook Deleter
                   04 ~ Exit           """)
    choice1 = input(f'{colorama.Fore.WHITE}                  ~/>')

    if choice1 == "3":

        webhookdeleter = input(f"{colorama.Fore.RED} \nWebhook link: {colorama.Fore.WHITE}")

        webhookchecker = requests.get(webhookdeleter)
        if webhookchecker.status_code == 404:
            print("The webhook is non-existent or already deleted")
            time.sleep(2)
            os.system("cls")
            webh()
        if webhookchecker.status_code == 10015:
            print("The webhook is non-existent or already deleted")
            time.sleep(2)
            os.system("cls")
            webh()
        if webhookchecker.status_code == 401:
            print("The webhook is non-existent or already deleted")
            time.sleep(2)
            webh()
        else:
            hook = Webhook(webhookdeleter)
            print(f"{colorama.Fore.YELLOW}    Wait...")
            x = requests.delete(webhookdeleter)
            print(f"{colorama.Fore.LIGHTGREEN_EX}  Webhook deleted.")
            time.sleep(3)
            webh()
        

    if choice1 == "1":
        webhooklink = input(f"{colorama.Fore.RED} \nWebhook link: {colorama.Fore.WHITE}")
        webhookmsg = input(f"{colorama.Fore.RED} \nMessage: {colorama.Fore.WHITE}")
        data = {
            "content" : "discord.gg/opiumtools @everyone @here",
            "username" : "Opium WebhookTool"
        }
        data["embeds"] = [
        {
        "description" : f"{webhookmsg}",
        "title" : "Opium WebhookTool"
        }
]
        result = requests.post(webhooklink, json = data)
        print("\n\nMessage sended.")
        time.sleep(3)
        webh()

    if choice1 == "2":
        webhooklink = input(f"{colorama.Fore.RED} \nWebhook link: {colorama.Fore.WHITE}")
        webhookmsg = input(f"{colorama.Fore.RED} \nMessage: {colorama.Fore.WHITE}")
        data = {
            "content" : "discord.gg/opiumtools @everyone @here",
            "username" : "Opium WebhookTool"
        }
        data["embeds"] = [
        {
        "description" : f"{webhookmsg}",
        "title" : "Opium WebhookTool"
        }
]

        count = 0
        while (count < 50):   
            count = count + 1
            print(f"{colorama.Fore.RED}Message sended")
            result = requests.post(webhooklink, json = data)
        print("\n\nSpam ended.")
        time.sleep(2)
        webh()   

    if choice1 == "4":
        print(f"{colorama.Fore.LIGHTBLUE_EX}Developer: {colorama.Fore.WHITE}OpiumTools\n{colorama.Fore.LIGHTBLUE_EX}Discord: {colorama.Fore.WHITE}Proxy_0\n")
        input(f"\n\n{colorama.Fore.RED}Press ENTER to exit")
        os.system("cls")
        webh()


    else:
        os.system("cls")
        webh()



main()
webh()